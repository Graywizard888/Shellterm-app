if [ ! -f /data/data/com.gwterm/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.gwterm/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.gwterm/files/home/.termux
	cp /data/data/com.gwterm/files/usr/share/examples/termux/termux.properties /data/data/com.gwterm/files/home/.termux/
fi
