##
## This script is sourced by /data/data/com.gwterm/files/usr/bin/login before executing shell.
##
