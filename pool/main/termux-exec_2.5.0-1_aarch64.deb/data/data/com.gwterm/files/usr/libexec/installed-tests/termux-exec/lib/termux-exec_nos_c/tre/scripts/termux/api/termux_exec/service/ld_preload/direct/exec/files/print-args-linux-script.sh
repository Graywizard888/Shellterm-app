#!/data/data/com.gwterm/files/usr/bin/sh

echo "$@"
